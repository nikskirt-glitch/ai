package com.aicommand;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

import java.io.IOException;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.charset.StandardCharsets;
import java.time.Duration;
import java.util.Locale;

/** Minimal blocking client for the Anthropic Messages API and OpenAI-style chat completions. */
public final class LlmClient {
    private static final HttpClient HTTP = HttpClient.newBuilder()
            .connectTimeout(Duration.ofSeconds(15))
            .build();

    public record Settings(String provider, String url, String key, String model, int timeoutSeconds) {}

    private LlmClient() {}

    /** Blocking call: never run this on the server thread. */
    public static String complete(Settings s, String system, String user) throws IOException, InterruptedException {
        if (s.key() == null || s.key().isBlank()) {
            throw new IOException("API key is empty. Set apiKey in config/aicommand-common.toml "
                    + "or the AI_COMMAND_API_KEY environment variable.");
        }
        boolean anthropic = s.provider().trim().toLowerCase(Locale.ROOT).equals("anthropic");

        String url = resolveUrl(s, anthropic);
        JsonObject body = new JsonObject();
        body.addProperty("model", s.model());

        HttpRequest.Builder req = HttpRequest.newBuilder(URI.create(url))
                .timeout(Duration.ofSeconds(s.timeoutSeconds()))
                .header("content-type", "application/json");

        if (anthropic) {
            body.addProperty("max_tokens", 4096);
            body.addProperty("system", system);
            JsonArray messages = new JsonArray();
            messages.add(message("user", user));
            body.add("messages", messages);
            req.header("x-api-key", s.key()).header("anthropic-version", "2023-06-01");
        } else {
            JsonArray messages = new JsonArray();
            messages.add(message("system", system));
            messages.add(message("user", user));
            body.add("messages", messages);
            req.header("authorization", "Bearer " + s.key());
        }

        req.POST(HttpRequest.BodyPublishers.ofString(body.toString(), StandardCharsets.UTF_8));
        HttpResponse<String> resp = HTTP.send(req.build(), HttpResponse.BodyHandlers.ofString(StandardCharsets.UTF_8));

        if (resp.statusCode() / 100 != 2) {
            String b = resp.body() == null ? "" : resp.body();
            throw new IOException("HTTP " + resp.statusCode() + ": " + (b.length() > 300 ? b.substring(0, 300) : b));
        }

        JsonObject json = JsonParser.parseString(resp.body()).getAsJsonObject();
        return anthropic ? extractAnthropic(json) : extractOpenAi(json);
    }

    private static JsonObject message(String role, String content) {
        JsonObject o = new JsonObject();
        o.addProperty("role", role);
        o.addProperty("content", content);
        return o;
    }

    private static String resolveUrl(Settings s, boolean anthropic) {
        String url = s.url() == null ? "" : s.url().trim();
        if (url.isEmpty()) {
            return anthropic
                    ? "https://api.anthropic.com/v1/messages"
                    : "https://api.openai.com/v1/chat/completions";
        }
        if (!anthropic && !url.endsWith("/chat/completions")) {
            while (url.endsWith("/")) url = url.substring(0, url.length() - 1);
            url = url + "/chat/completions";
        }
        return url;
    }

    private static String extractAnthropic(JsonObject json) throws IOException {
        JsonArray content = json.getAsJsonArray("content");
        if (content == null) throw new IOException("Unexpected response: no content");
        StringBuilder sb = new StringBuilder();
        for (JsonElement e : content) {
            JsonObject part = e.getAsJsonObject();
            if (part.has("type") && "text".equals(part.get("type").getAsString()) && part.has("text")) {
                sb.append(part.get("text").getAsString());
            }
        }
        return sb.toString();
    }

    private static String extractOpenAi(JsonObject json) throws IOException {
        JsonArray choices = json.getAsJsonArray("choices");
        if (choices == null || choices.isEmpty()) throw new IOException("Unexpected response: no choices");
        JsonObject msg = choices.get(0).getAsJsonObject().getAsJsonObject("message");
        if (msg == null || !msg.has("content") || msg.get("content").isJsonNull()) {
            throw new IOException("Unexpected response: empty message");
        }
        return msg.get("content").getAsString();
    }
}
