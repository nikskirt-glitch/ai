package com.aicommand;

import com.mojang.logging.LogUtils;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.event.RegisterCommandsEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.ModLoadingContext;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.config.ModConfig;
import org.slf4j.Logger;

@Mod(AiCommandMod.MODID)
public class AiCommandMod {
    public static final String MODID = "aicommand";
    public static final Logger LOGGER = LogUtils.getLogger();

    public AiCommandMod() {
        ModLoadingContext.get().registerConfig(ModConfig.Type.COMMON, AiConfig.SPEC);
        MinecraftForge.EVENT_BUS.register(this);
    }

    @SubscribeEvent
    public void onRegisterCommands(RegisterCommandsEvent event) {
        AiCommand.register(event.getDispatcher());
    }
}
