package com.aicommand;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.exceptions.CommandSyntaxException;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraftforge.registries.ForgeRegistries;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * /ai <wish>
 *
 * The wish is sent to an LLM together with a short description of the world around the player.
 * The model answers with a JSON object {"say": "...", "commands": ["setblock ...", ...]}.
 * The commands are then run on the server thread, but only if their root command is in the
 * allowedCommands config list, and with a limited permission level.
 */
public final class AiCommand {
    private static final int MAX_WISH_LENGTH = 500;

    private static final Set<UUID> PENDING = ConcurrentHashMap.newKeySet();
    private static final Map<UUID, Long> LAST_USE = new ConcurrentHashMap<>();
    private static final ExecutorService POOL = Executors.newCachedThreadPool(r -> {
        Thread t = new Thread(r, "AiCommand-HTTP");
        t.setDaemon(true);
        return t;
    });

    private static final String SYSTEM_PROMPT = """
            You are the "world AI" inside a Minecraft Java Edition 1.20.1 world (Forge).
            The player types a wish in chat and you make it happen by writing vanilla Minecraft commands.

            OUTPUT FORMAT - reply with ONE JSON object and nothing else (no markdown, no code fences):
            {"say": "short message to the player", "commands": ["command 1", "command 2"]}

            RULES
            - Write commands WITHOUT a leading slash.
            - Commands run as the player, at the player's position and rotation. "~ ~ ~" is the player's feet.
              Use "^ ^ ^5" for 5 blocks in front of where the player looks. Use ~ for everything near the player.
            - The context message tells you the player's position and what block they are looking at.
              Use absolute coordinates from it when you need to build at the looked-at block.
            - Version is 1.20.1: use the OLD NBT syntax, not item components. Examples:
                give @s minecraft:diamond_sword{Enchantments:[{id:"minecraft:sharpness",lvl:5}]} 1
                summon minecraft:zombie ~ ~ ~ {CustomName:'{"text":"Boss"}',Health:100f,Attributes:[{Name:"generic.max_health",Base:100}]}
                summon minecraft:lightning_bolt ~ ~ ~
            - For buildings use fill (with hollow / outline / replace) and setblock. One fill may cover at most
              32768 blocks. Build things next to the player, not on top of them, and leave room to walk.
            - Use at most {MAX} commands. Prefer a few big fill commands over many setblock commands.
            - Only these root commands are allowed, everything else is blocked: {ALLOWED}
            - Do not destroy the player's surroundings unless the wish clearly asks for it.
            - If the wish is impossible, unclear or unsafe, return an empty commands list and explain in "say".
            - "say" must be short (max 2 sentences) and in the same language as the player's wish.
            """;

    private AiCommand() {}

    public static void register(CommandDispatcher<CommandSourceStack> dispatcher) {
        dispatcher.register(Commands.literal("ai")
                .requires(src -> src.hasPermission(requiredLevel()))
                .then(Commands.argument("wish", StringArgumentType.greedyString())
                        .executes(ctx -> run(ctx.getSource(), StringArgumentType.getString(ctx, "wish")))));
    }

    private static int requiredLevel() {
        try {
            return AiConfig.PERMISSION_LEVEL.get();
        } catch (IllegalStateException e) {
            return 2; // config not loaded yet
        }
    }

    private static int run(CommandSourceStack src, String wish) {
        ServerPlayer player;
        try {
            player = src.getPlayerOrException();
        } catch (CommandSyntaxException e) {
            src.sendFailure(Component.literal("/ai можно использовать только игроку."));
            return 0;
        }

        wish = wish.trim();
        if (wish.isEmpty()) {
            src.sendFailure(Component.literal("Напиши, что хочешь: /ai построй каменный домик"));
            return 0;
        }
        if (wish.length() > MAX_WISH_LENGTH) {
            src.sendFailure(Component.literal("Слишком длинное желание (максимум " + MAX_WISH_LENGTH + " символов)."));
            return 0;
        }

        UUID id = player.getUUID();
        long now = System.currentTimeMillis();
        long cooldownMs = AiConfig.COOLDOWN_SECONDS.get() * 1000L;
        Long last = LAST_USE.get(id);
        if (last != null && now - last < cooldownMs) {
            long left = (cooldownMs - (now - last) + 999) / 1000;
            src.sendFailure(Component.literal("Подожди ещё " + left + " сек."));
            return 0;
        }
        if (!PENDING.add(id)) {
            src.sendFailure(Component.literal("Предыдущий запрос ещё обрабатывается."));
            return 0;
        }
        LAST_USE.put(id, now);

        // Read all config values on the server thread.
        String key = AiConfig.API_KEY.get();
        if (key == null || key.isBlank()) key = System.getenv("AI_COMMAND_API_KEY");
        LlmClient.Settings settings = new LlmClient.Settings(
                AiConfig.PROVIDER.get(), AiConfig.API_URL.get(), key,
                AiConfig.MODEL.get(), AiConfig.TIMEOUT_SECONDS.get());
        int maxCommands = AiConfig.MAX_COMMANDS.get();
        int execLevel = AiConfig.EXECUTION_LEVEL.get();
        Set<String> allowed = new HashSet<>();
        for (String s : AiConfig.ALLOWED_COMMANDS.get()) allowed.add(s.toLowerCase(Locale.ROOT));

        String system = SYSTEM_PROMPT
                .replace("{MAX}", String.valueOf(maxCommands))
                .replace("{ALLOWED}", String.join(", ", new java.util.TreeSet<>(allowed)));
        String userMessage = buildContext(player) + "\nPlayer's wish: " + wish;

        MinecraftServer server = src.getServer();
        player.sendSystemMessage(Component.literal("[AI] Думаю..."));

        POOL.execute(() -> {
            try {
                String answer = LlmClient.complete(settings, system, userMessage);
                Plan plan = Plan.parse(answer);
                server.execute(() -> {
                    try {
                        apply(server, id, plan, maxCommands, execLevel, allowed);
                    } finally {
                        PENDING.remove(id);
                    }
                });
            } catch (Exception e) {
                AiCommandMod.LOGGER.warn("AI request failed: {}", e.toString());
                server.execute(() -> {
                    try {
                        ServerPlayer p = server.getPlayerList().getPlayer(id);
                        if (p != null) p.sendSystemMessage(Component.literal("[AI] Ошибка: " + shorten(e.getMessage(), 250)));
                    } finally {
                        PENDING.remove(id);
                    }
                });
            }
        });
        return 1;
    }

    private static String buildContext(ServerPlayer player) {
        ServerLevel level = player.serverLevel();
        BlockPos pos = player.blockPosition();
        String biome = level.getBiome(pos).unwrapKey()
                .map(k -> k.location().toString()).orElse("unknown");

        StringBuilder sb = new StringBuilder();
        sb.append("World context:\n");
        sb.append("- player: ").append(player.getGameProfile().getName()).append('\n');
        sb.append("- dimension: ").append(level.dimension().location()).append('\n');
        sb.append("- player block position: ").append(pos.getX()).append(' ').append(pos.getY()).append(' ').append(pos.getZ()).append('\n');
        sb.append("- facing: ").append(player.getDirection().getName()).append('\n');

        HitResult hit = player.pick(20.0D, 0.0F, false);
        if (hit.getType() == HitResult.Type.BLOCK) {
            BlockPos b = ((BlockHitResult) hit).getBlockPos();
            sb.append("- looking at block at: ").append(b.getX()).append(' ').append(b.getY()).append(' ').append(b.getZ())
                    .append(" (").append(ForgeRegistries.BLOCKS.getKey(level.getBlockState(b).getBlock())).append(")\n");
        } else {
            sb.append("- looking at: nothing within 20 blocks\n");
        }
        sb.append("- biome: ").append(biome).append('\n');
        sb.append("- time of day (ticks): ").append(level.getDayTime() % 24000L).append('\n');
        sb.append("- raining: ").append(level.isRaining()).append('\n');
        return sb.toString();
    }

    private static void apply(MinecraftServer server, UUID id, Plan plan, int maxCommands,
                              int execLevel, Set<String> allowed) {
        ServerPlayer player = server.getPlayerList().getPlayer(id);
        if (player == null) return; // player left while waiting

        if (!plan.say.isBlank()) {
            player.sendSystemMessage(Component.literal("[AI] " + shorten(plan.say, 300)));
        }
        if (plan.commands.isEmpty()) return;

        CommandSourceStack source = player.createCommandSourceStack()
                .withPermission(execLevel)
                .withSuppressedOutput();

        int ok = 0, failed = 0, blocked = 0;
        String firstError = null;
        int index = 0;
        for (String raw : plan.commands) {
            if (index++ >= maxCommands) {
                player.sendSystemMessage(Component.literal("[AI] Лимит команд (" + maxCommands + ") достигнут, остальные пропущены."));
                break;
            }
            String cmd = raw.trim();
            if (cmd.startsWith("/")) cmd = cmd.substring(1).trim();
            if (cmd.isEmpty()) continue;

            String root = cmd.split("\\s+", 2)[0].toLowerCase(Locale.ROOT);
            if (!allowed.contains(root)) {
                blocked++;
                AiCommandMod.LOGGER.info("Blocked AI command (not in allowedCommands): {}", cmd);
                continue;
            }
            try {
                server.getCommands().getDispatcher().execute(cmd, source);
                ok++;
            } catch (CommandSyntaxException e) {
                failed++;
                if (firstError == null) firstError = e.getMessage();
                AiCommandMod.LOGGER.info("AI command failed: {} -> {}", cmd, e.getMessage());
            } catch (Exception e) {
                failed++;
                if (firstError == null) firstError = e.toString();
                AiCommandMod.LOGGER.warn("AI command crashed: {}", cmd, e);
            }
        }

        StringBuilder sum = new StringBuilder("[AI] Выполнено команд: ").append(ok);
        if (failed > 0) sum.append(", с ошибкой: ").append(failed);
        if (blocked > 0) sum.append(", заблокировано: ").append(blocked);
        player.sendSystemMessage(Component.literal(sum.toString()));
        if (firstError != null) {
            player.sendSystemMessage(Component.literal("[AI] Первая ошибка: " + shorten(firstError, 200)));
        }
    }

    private static String shorten(String s, int max) {
        if (s == null) return "unknown";
        return s.length() <= max ? s : s.substring(0, max) + "...";
    }

    /** Parsed model answer. */
    private static final class Plan {
        final String say;
        final List<String> commands;

        private Plan(String say, List<String> commands) {
            this.say = say;
            this.commands = commands;
        }

        static Plan parse(String text) throws java.io.IOException {
            int start = text.indexOf('{');
            int end = text.lastIndexOf('}');
            if (start < 0 || end <= start) {
                throw new java.io.IOException("Модель вернула ответ не в формате JSON.");
            }
            try {
                JsonObject obj = JsonParser.parseString(text.substring(start, end + 1)).getAsJsonObject();
                String say = obj.has("say") && !obj.get("say").isJsonNull() ? obj.get("say").getAsString() : "";
                List<String> cmds = new ArrayList<>();
                if (obj.has("commands") && obj.get("commands").isJsonArray()) {
                    JsonArray arr = obj.getAsJsonArray("commands");
                    for (JsonElement e : arr) {
                        if (e.isJsonPrimitive()) cmds.add(e.getAsString());
                    }
                }
                return new Plan(say, cmds);
            } catch (RuntimeException e) {
                throw new java.io.IOException("Не удалось разобрать ответ модели: " + e.getMessage());
            }
        }
    }
}
