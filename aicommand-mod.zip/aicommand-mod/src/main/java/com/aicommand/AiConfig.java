package com.aicommand;

import net.minecraftforge.common.ForgeConfigSpec;

import java.util.List;

/** Config file: config/aicommand-common.toml */
public final class AiConfig {
    public static final ForgeConfigSpec SPEC;

    public static final ForgeConfigSpec.ConfigValue<String> PROVIDER;
    public static final ForgeConfigSpec.ConfigValue<String> API_URL;
    public static final ForgeConfigSpec.ConfigValue<String> API_KEY;
    public static final ForgeConfigSpec.ConfigValue<String> MODEL;
    public static final ForgeConfigSpec.IntValue TIMEOUT_SECONDS;

    public static final ForgeConfigSpec.IntValue PERMISSION_LEVEL;
    public static final ForgeConfigSpec.IntValue EXECUTION_LEVEL;
    public static final ForgeConfigSpec.IntValue COOLDOWN_SECONDS;
    public static final ForgeConfigSpec.IntValue MAX_COMMANDS;
    public static final ForgeConfigSpec.ConfigValue<List<? extends String>> ALLOWED_COMMANDS;

    static {
        ForgeConfigSpec.Builder b = new ForgeConfigSpec.Builder();

        b.push("llm");
        PROVIDER = b.comment(
                "Which API format to use: \"anthropic\" (Claude) or \"openai\" (OpenAI and any OpenAI-compatible server,",
                "e.g. OpenRouter, Ollama, LM Studio).")
                .define("provider", "anthropic");
        API_URL = b.comment(
                "Leave empty for the default of the provider.",
                "anthropic default: https://api.anthropic.com/v1/messages",
                "openai default:    https://api.openai.com/v1/chat/completions",
                "For OpenAI-compatible servers you can put a base URL such as http://localhost:11434/v1")
                .define("apiUrl", "");
        API_KEY = b.comment(
                "Your API key. If empty, the environment variable AI_COMMAND_API_KEY is used.",
                "Never share this file with the key inside.")
                .define("apiKey", "");
        MODEL = b.comment("Model name, e.g. claude-sonnet-5-5 or gpt-4o.")
                .define("model", "claude-sonnet-5-5");
        TIMEOUT_SECONDS = b.comment("How long to wait for the model, in seconds.")
                .defineInRange("timeoutSeconds", 90, 5, 600);
        b.pop();

        b.push("safety");
        PERMISSION_LEVEL = b.comment(
                "Permission level needed to use /ai (0 = everyone, 2 = cheats/gamemaster, 4 = owner).",
                "In singleplayer with cheats enabled you are level 4.")
                .defineInRange("permissionLevel", 2, 0, 4);
        EXECUTION_LEVEL = b.comment(
                "Permission level the AI-generated commands run with (0-2). Level 2 is needed for",
                "setblock/fill/summon/give. Commands outside allowedCommands never run.")
                .defineInRange("executionLevel", 2, 0, 2);
        COOLDOWN_SECONDS = b.comment("Minimum seconds between two /ai requests of one player.")
                .defineInRange("cooldownSeconds", 5, 0, 3600);
        MAX_COMMANDS = b.comment("Maximum number of commands executed per request.")
                .defineInRange("maxCommands", 40, 1, 500);
        ALLOWED_COMMANDS = b.comment(
                "Only these root commands may be run by the AI. Everything else is blocked.",
                "op, stop, ban, whitelist, etc. are intentionally not in the default list.")
                .defineListAllowEmpty("allowedCommands", List.of(
                        "setblock", "fill", "clone", "place", "summon", "kill", "give", "clear",
                        "tp", "teleport", "time", "weather", "effect", "enchant", "particle",
                        "playsound", "title", "say", "tellraw", "gamerule", "gamemode", "xp",
                        "attribute", "item", "loot", "damage", "spawnpoint", "setworldspawn",
                        "difficulty", "tag", "execute"
                ), o -> o instanceof String);
        b.pop();

        SPEC = b.build();
    }

    private AiConfig() {}
}
